import argparse
import pathlib
import subprocess

import grpc
import numpy as np
import tritonclient.grpc as grpcclient

import tms_python_client.proto.common_pb2 as common
import tms_python_client.proto.Tms.lease_pb2 as lease
import tms_python_client.proto.Tms.lease_pb2_grpc as lease_grpc

FILE_SERVER_URL = "host.minikube.internal"
FILE_SERVER_PORT = 8000

LEASE_STATE = {
    0: "Unknown",
    1: "Pending",
    2: "Valid",
    3: "Released",
    4: "Expired",
    5: "Error",
}


def request_lease(tms_url: str, repo_url: str, repo_port: int, model_name: str):
    """Requests a lease for a single model from the specified TMS instance

    :param tms_url:         The URL of the gRPC endpoint for Triton Management Service
    :param repo_url:        The URL of the HTTP model repository
    :param repo_port:       The port where the HTTP Model Repostory is being served
    :param mode_name:       The name of the model to be included in the lease

    :return:                Valid lease response
    :raises RuntimeError:   If unable to sucessfully request the lease
    """
    model_urn = f"http://{repo_url}:{repo_port}/{model_name}.zip"

    # Open gRPC Channel
    with grpc.insecure_channel(tms_url) as channel:
        stub = lease_grpc.LeaseStub(channel)

        # Header for all TMS GRPC Requests
        version = common.Version(major=0, minor=9, patch=0)
        header = common.RequestHeader(
            api_version=version, user_agent="example", authentication=""
        )

        # Specify lease parameters. In this case model name and urn and 0 gpus,
        # everything else will be default.
        model = lease.LeaseAcquireRequest.ModelRequest(
            model_urn=model_urn, model_name=model_name
        )
        triton_resource_requests = lease.ContainerResourceRequests(gpu=0)

        # Submit lease request. Response will be a stream, so we loop through
        print("Requesting Lease for", model_name)
        lease_request = lease.LeaseAcquireRequest(
            header=header,
            models=[model],
            triton_resource_requests=triton_resource_requests,
        )
        acquire_response_stream = stub.Acquire(lease_request)

        for acquire_response in acquire_response_stream:
            print("Lease:", LEASE_STATE[acquire_response.lease_state])

            if acquire_response.lease_state == lease.LEASE_STATE_VALID:
                print(
                    f"Lease {acquire_response.lease_id.hex()} acquired "
                    f"at {acquire_response.triton_urn}"
                )
                return acquire_response

        # If stream ends without ever reaching VALID state, throw error
        raise RuntimeError(f"Failed to acquire lease for {model_name}")


def triton_infer(model_lease, model_name):
    """Given a valid lease, submits an inference request and prints the output

    Note: will only work *inside* the kubernetes cluster by default,
          as TMS does not automatically provide any ingress.

    :param model_lease: a valid LeaseAcquireResponse from TMS
    :param model_name:  the name of the model to submit the inference request to
    """
    triton_client = grpcclient.InferenceServerClient(url=model_lease.triton_urn)

    inputs = [
        grpcclient.InferInput("INPUT0", [1, 16], "INT32"),
        grpcclient.InferInput("INPUT0", [1, 16], "INT32"),
    ]
    inputs[0].set_data_from_numpy(np.ones(shape=(1, 16), dtype=np.int32))
    inputs[1].set_data_from_numpy(np.ones(shape=(1, 16), dtype=np.int32))

    results = triton_client.infer(model_name=model_name, inputs=inputs)

    output_0 = results.as_numpy("OUTPUT0")
    output_1 = results.as_numpy("OUTPUT1")

    print(output_0)
    print(output_1)


def release_lease(tms_url: str, lease_id):
    """ Release (i.e. remove) a lease from TMS given the lease ID

    :param tms_url:  The URL of the gRPC endpoint for Triton Management Service
    :param lease_id: The ID of the lease that you are releasing
    """

    # open gRPC Channel
    with grpc.insecure_channel(tms_url) as channel:
        stub = lease_grpc.LeaseStub(channel)

        # Header for all TMS gRPC requests
        version = common.Version(major=0, minor=9, patch=0)
        header = common.RequestHeader(
            api_version=version, user_agent="example", authentication=""
        )

        # Submit lease release request. Not a stream, so we can directly return
        # the response.
        release_request = lease.LeaseReleaseRequest(header=header, lease_id=lease_id)

        release_response = stub.Release(release_request)
        print(f"Released Lease {lease_id.hex()}")
        return release_response


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Example of using the grpc API in python to create and "
        "release a TMS lease. Will also optionally launch an HTTP server to "
        "act as a model repository for the `simple` model."
    )
    parser.add_argument("-u", "--tms-url", type=str, required=True, help="URL for TMS")
    parser.add_argument(
        "--deploy-repo",
        action="store_true",
        default=True,
        help="Deploy HTTP Model repo as part of example",
    )
    parser.add_argument(
        "--repo-url",
        type=str,
        default=FILE_SERVER_URL,
        help=f"URL of the model repository. Default is {FILE_SERVER_URL}",
    )
    parser.add_argument(
        "--repo-port",
        type=int,
        default=FILE_SERVER_PORT,
        help=f"HTTP Port of the model repository. Default is {FILE_SERVER_PORT}",
    )

    args = parser.parse_args()
    file_server_args = [
        "python",
        "-m",
        "http.server",
        "--directory",
        pathlib.Path(__file__).parent,
        str(FILE_SERVER_PORT),
    ]

    if args.deploy_repo:
        with subprocess.Popen(file_server_args) as model_server:
            simple_lease = request_lease(
                args.tms_url, args.repo_url, args.repo_port, "simple"
            )
            # Only works inside K8s cluster:
            # triton_infer(simple_lease, "simple")
            release_lease(args.tms_url, simple_lease.lease_id)
            model_server.kill()
    else:
        simple_lease = request_lease(
            args.tms_url, args.repo_url, args.repo_port, "simple"
        )
        # Only works inside K8s cluster:
        # triton_infer(simple_lease, "simple")
        release_lease(args.tms_url, simple_lease.lease_id)
