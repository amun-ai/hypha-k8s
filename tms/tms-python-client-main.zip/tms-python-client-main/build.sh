## Unzip protobuf files from NGC package
rm -r proto
unzip tms_grpc_api_v0.9.0/triton-management-service_grpc-api-v0.9.0.zip -d proto

## Move protobuf files to the right directories. This is because the import paths created by the protobuf compiler
## for python depend on the relative locations of the protobuf files themselves
mkdir proto/Tms
mv proto/allowlist.proto proto/Tms/allowlist.proto
mv proto/lease-event.proto proto/Tms/lease-event.proto
mv proto/lease.proto proto/Tms/lease.proto

## Add a top-level "proto" directory to the protobuf import paths. This allows us to put the protoc generated python
## files into their own subdirectory in the python package
find ./proto -type f -exec sed -i 's/import public "\(.*\)"/import public "proto\/\1"/g' {} +

## Compile the protobuf files into python files
rm -r tms_python_client/proto
python -m grpc_tools.protoc --python_out=tms_python_client --grpc_python_out=tms_python_client --proto_path . proto/*.proto
python -m grpc_tools.protoc --python_out=tms_python_client --grpc_python_out=tms_python_client --proto_path . proto/Tms/*.proto

## Not sure if this is necessary
touch tms_python_client/proto/__init__.py
touch tms_python_client/proto/Tms/__init__.py

## Convert the (non-functional) relative import paths in the python files to absolute import paths (relative to the python package)
find ./tms_python_client -name *_pb2*.py -exec sed -i 's/from proto\(.*\) import \(.*\)/from tms_python_client.proto\1 import \2/g' {} +

## Build the package into a wheel
poetry build