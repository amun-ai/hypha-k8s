# TMS Python Client

## Building the Python client

1. Download NGC CLI

1. Pull the protobuf/grpc files

    ```bash
    ngc registry resource download-version "frrkiejzzo3k/tms_grpc_api:0.9.0"
    ```

1. Build client

    ```bash
    ./build.sh
    ```
